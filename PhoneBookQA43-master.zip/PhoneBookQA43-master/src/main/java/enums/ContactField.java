package enums;

public enum ContactField {
    NAME,
    LAST_NAME,
    EMAIL,
    PHONE_NUMBER,
    ADDRESS,
    DESCRIPTION

}
