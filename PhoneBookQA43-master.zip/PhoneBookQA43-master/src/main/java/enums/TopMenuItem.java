package enums;

public enum TopMenuItem {

    HOME, ABOUT, LOGIN, ADD, CONTACTS
}
